//
//  Color.swift
//  LogInUI
//
//  Created by Tahani on 5/5/18.
//  Copyright © 2018 Tahani. All rights reserved.
//

import UIKit
extension UIView { @objc var borderColor: UIColor { get { return UIColor(cgColor: layer.borderColor!) } set(value) { layer.borderColor = value.cgColor } } }
